import { Component, OnInit } from '@angular/core';
import { DataService } from 'src/app/services/data.service';
import { Scene } from 'src/app/interfaces/scene';
import { element } from 'protractor';

@Component({
  selector: 'app-scene1',
  templateUrl: './scene1.page.html',
  styleUrls: ['./scene1.page.scss'],
})
export class Scene1Page implements OnInit {
  displayScene: Scene;
  
  constructor(private dServe: DataService) {

  }

  scene: Scene
  ngOnInit() {
    this.nextScene(1);
  }

  nextScene(num: number) {
    console.log(this.dServe.getScene(num));
    this.scene = this.dServe.getScene(num);
  }
}
