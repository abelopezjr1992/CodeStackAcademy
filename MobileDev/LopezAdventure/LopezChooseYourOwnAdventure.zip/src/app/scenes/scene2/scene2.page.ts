import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-scene2',
  templateUrl: './scene2.page.html',
  styleUrls: ['./scene2.page.scss'],
})
export class Scene2Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
